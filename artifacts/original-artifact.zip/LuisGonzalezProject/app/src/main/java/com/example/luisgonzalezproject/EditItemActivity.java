package com.example.luisgonzalezproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class EditItemActivity extends AppCompatActivity {

    private EditText editName, editQty;
    private DatabaseHelper dbHelper;
    private String originalName; // Used to find the item in the database

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        dbHelper = new DatabaseHelper(this);

        // Linking Java to your XML IDs
        editName = findViewById(R.id.editItemName);
        editQty = findViewById(R.id.editItemQty);
        Button btnPlus = findViewById(R.id.btnIncrease);
        Button btnMinus = findViewById(R.id.btnDecrease);
        Button btnSave = findViewById(R.id.btnSaveUpdate);
        Button btnDelete = findViewById(R.id.btnDeleteItem); // Rubric requirement

        // 1. Get data passed from the Inventory Dashboard
        String itemDetails = getIntent().getStringExtra("ITEM_DETAILS");
        if (itemDetails != null) {
            // Parses "Hammer\n(25)" back into "Hammer" and "25"
            originalName = itemDetails.split("\n")[0];
            String qtyStr = itemDetails.substring(itemDetails.indexOf("(") + 1, itemDetails.indexOf(")"));
            editName.setText(originalName);
            editQty.setText(qtyStr);
        }

        // 2. Increment Quantity (+)
        btnPlus.setOnClickListener(v -> {
            int currentQty = Integer.parseInt(editQty.getText().toString());
            editQty.setText(String.valueOf(currentQty + 1));
        });

        // 3. Decrement Quantity (-)
        btnMinus.setOnClickListener(v -> {
            int currentQty = Integer.parseInt(editQty.getText().toString());
            if (currentQty > 0) {
                editQty.setText(String.valueOf(currentQty - 1));
            }
        });

        // 4. Save Changes & Check SMS
        btnSave.setOnClickListener(v -> {
            String newName = editName.getText().toString();
            int newQty = Integer.parseInt(editQty.getText().toString());

            // Save to DB
            dbHelper.updateItem(originalName, newName, newQty);

            // Trigger SMS if stock hits zero
            if (newQty == 0) {
                checkSmsPermissionAndSend(newName);
            }

            Toast.makeText(this, "Saved Successfully", Toast.LENGTH_SHORT).show();
            finish(); // Returns to Dashboard
        });

        // 5. Delete Item (Rubric: "Button for deleting that row")
        btnDelete.setOnClickListener(v -> {
            dbHelper.deleteSingleItem(originalName);
            Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    // --- SMS ALERT METHODS ---

    private void checkSmsPermissionAndSend(String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Trigger permission request if not granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            sendSMSAlert(itemName);
        }
    }

    private void sendSMSAlert(String itemName) {
        String phoneNumber = "1234567890"; // Supervisor number
        String message = "ALERT: Inventory for " + itemName + " has reached zero!";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Alert Sent to Supervisor", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed: Permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}