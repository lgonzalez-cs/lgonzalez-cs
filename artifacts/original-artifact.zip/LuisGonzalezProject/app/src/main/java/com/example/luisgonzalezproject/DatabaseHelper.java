package com.example.luisgonzalezproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Inventory.db";
    public static final String TABLE_NAME = "inventory_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "QUANTITY";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, QUANTITY INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Used by ADD NEW ITEM button
    public void addItem(String name, int qty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, qty);
        db.insert(TABLE_NAME, null, contentValues);
    }

    // Used by SAVE CHANGES button
    public void updateItem(String oldName, String newName, int newQty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, newName);
        contentValues.put(COL_3, newQty);
        // This ensures we update the specific item you clicked
        db.update(TABLE_NAME, contentValues, "NAME = ?", new String[]{oldName});
    }

    // Used by CLEAR ALL button
    public void deleteAllItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
    }

    public void deleteSingleItem(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Deletes the specific row matching the name passed from the edit screen
        db.delete(TABLE_NAME, "NAME = ?", new String[]{name});
        db.close();
    }
}