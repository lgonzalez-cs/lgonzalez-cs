package com.example.luisgonzalezproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Initialize UI elements (must be inside onCreate)
        final Button buttonSayHello = findViewById(R.id.buttonSayHello);
        final EditText nameText = findViewById(R.id.nameText);
        final EditText passwordText = findViewById(R.id.passwordText);

        // 2. Create the listener for login validation
        TextWatcher loginWatcher = new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String username = nameText.getText().toString().trim();
                String password = passwordText.getText().toString().trim();

                // Enable button only if both fields have text
                buttonSayHello.setEnabled(!username.isEmpty() && !password.isEmpty());
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        };

        // 3. Attach the listener to the input fields
        nameText.addTextChangedListener(loginWatcher);
        passwordText.addTextChangedListener(loginWatcher);

    } // This brace ends onCreate correctly

    // 4. SayHello function (must be OUTSIDE onCreate)
    @SuppressLint("SetTextI18n")
    public void SayHello(View view) {
        EditText nameText = findViewById(R.id.nameText);

        // Check if the user entered a name (your login requirement)
        if (nameText.getText() != null && !nameText.getText().toString().isEmpty()) {

            // Create an Intent to go from MainActivity to InventoryActivity
            Intent intent = new Intent(this, InventoryActivity.class);

            // Optional: Pass the username to the next screen
            intent.putExtra("USER_NAME", nameText.getText().toString());

            startActivity(intent);
        }
    }
}