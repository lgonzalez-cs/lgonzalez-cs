package com.example.luisgonzalezproject;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private GridView inventoryGrid;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // 1. Ask for SMS Permission
        if (androidx.core.content.ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {

            androidx.core.app.ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.SEND_SMS}, 1);
        }

        // 2. Initialize Database and UI
        dbHelper = new DatabaseHelper(this);
        inventoryGrid = findViewById(R.id.inventoryGrid);

        // 3. Link Buttons to your XML IDs
        Button btnAdd = findViewById(R.id.btnAddItem);
        Button btnRefresh = findViewById(R.id.btnRefresh);
        Button btnClear = findViewById(R.id.btnClearAll);

        // 4. Set Button Actions
        btnAdd.setOnClickListener(v -> showAddItemDialog());

        btnRefresh.setOnClickListener(v -> displayAllItems());

        btnClear.setOnClickListener(v -> {
            dbHelper.deleteAllItems();
            displayAllItems();
            Toast.makeText(this, "Inventory Cleared", Toast.LENGTH_SHORT).show();
        });

        // 5. Grid Click to Edit
        inventoryGrid.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = (String) parent.getItemAtPosition(position);
            Intent intent = new Intent(InventoryActivity.this, EditItemActivity.class);
            intent.putExtra("ITEM_DETAILS", selectedItem);
            startActivity(intent);
        });

        displayAllItems();
    }

    // This method handles the popup to add items
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        final EditText inputName = new EditText(this);
        inputName.setHint("Item Name");
        final EditText inputQty = new EditText(this);
        inputQty.setHint("Quantity");
        inputQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(inputName);
        layout.addView(inputQty);
        builder.setView(layout);

        // FIX: Removed the duplicate/nested PositiveButton from image_a7199a.png
        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = inputName.getText().toString();
            String qtyStr = inputQty.getText().toString();

            if (!name.isEmpty() && !qtyStr.isEmpty()) {
                dbHelper.addItem(name, Integer.parseInt(qtyStr));
                displayAllItems(); // Updates the grid immediately
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // This method refreshes the grid from the database
    public void displayAllItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME, null);
        ArrayList<String> itemList = new ArrayList<>();

        while (cursor.moveToNext()) {
            String name = cursor.getString(1);
            int qty = cursor.getInt(2);
            itemList.add(name + "\n(" + qty + ")");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, itemList);
        inventoryGrid.setAdapter(adapter);
        cursor.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayAllItems();
    }
}