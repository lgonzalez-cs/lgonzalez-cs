package com.example.luisgonzalezproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText usernameField = findViewById(R.id.username);
        EditText passwordField = findViewById(R.id.password);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnLogin.setOnClickListener(v -> {
            String user = usernameField.getText().toString();
            String pass = passwordField.getText().toString();

            // Simple check: In a real app, verify with DatabaseHelper
            if (!user.isEmpty() && !pass.isEmpty()) {
                // Navigate to Inventory Grid upon authentication
                Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                startActivity(intent);
                finish(); // Prevents user from going back to login screen
            } else {
                Toast.makeText(this, "Please enter credentials", Toast.LENGTH_SHORT).show();
            }
        });

        btnCreateAccount.setOnClickListener(v -> {
            // Logic to save new user to database
            Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show();
        });
    }
}